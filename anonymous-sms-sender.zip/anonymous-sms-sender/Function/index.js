const functions = require('firebase-functions');
const cors = require('cors')({ origin: true });
const twilio = require('twilio');

const accountSid = 'AC7d28088f70adcdf253cb09f30014e0bd';
const authToken = '0f1e2f77ed9a2cf43870db38c9a985b0';
const fromNumber = '+8801300143398';

const client = twilio(accountSid, authToken);

exports.sendAnonymousSMS = functions.https.onRequest((req, res) => {
  cors(req, res, () => {
    const { to, message } = req.body;

    client.messages
      .create({
        body: message,
        from: fromNumber,
        to: to
      })
      .then(msg => res.status(200).send(`মেসেজ পাঠানো হয়েছে! SID: ${msg.sid}`))
      .catch(err => res.status(500).send(`ত্রুটি: ${err.message}`));
  });
});